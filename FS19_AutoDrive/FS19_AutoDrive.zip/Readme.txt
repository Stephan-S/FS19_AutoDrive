Tutorial can be found here:

https://github.com/Stephan-S/AutoDrive/wiki/English-Tutorial

Anleitungen gibt es hier:

https://github.com/Stephan-S/AutoDrive/wiki/Deutsche-Anleitung